'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import KanaGame from '@/components/kana-game'

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <KanaGame />
    </main>
  )
}
