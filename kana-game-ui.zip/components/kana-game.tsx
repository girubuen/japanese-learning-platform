'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Volume2, ArrowLeft } from 'lucide-react'

interface KanaCharacter {
  id: string
  kana: string
  romaji: string
  type: 'hiragana' | 'katakana'
}

const HIRAGANA_DATA: KanaCharacter[] = [
  { id: 'h1', kana: 'あ', romaji: 'a', type: 'hiragana' },
  { id: 'h2', kana: 'い', romaji: 'i', type: 'hiragana' },
  { id: 'h3', kana: 'う', romaji: 'u', type: 'hiragana' },
  { id: 'h4', kana: 'え', romaji: 'e', type: 'hiragana' },
  { id: 'h5', kana: 'お', romaji: 'o', type: 'hiragana' },
  { id: 'h6', kana: 'か', romaji: 'ka', type: 'hiragana' },
  { id: 'h7', kana: 'き', romaji: 'ki', type: 'hiragana' },
  { id: 'h8', kana: 'く', romaji: 'ku', type: 'hiragana' },
]

const KATAKANA_DATA: KanaCharacter[] = [
  { id: 'k1', kana: 'ア', romaji: 'a', type: 'katakana' },
  { id: 'k2', kana: 'イ', romaji: 'i', type: 'katakana' },
  { id: 'k3', kana: 'ウ', romaji: 'u', type: 'katakana' },
  { id: 'k4', kana: 'エ', romaji: 'e', type: 'katakana' },
  { id: 'k5', kana: 'オ', romaji: 'o', type: 'katakana' },
  { id: 'k6', kana: 'カ', romaji: 'ka', type: 'katakana' },
  { id: 'k7', kana: 'キ', romaji: 'ki', type: 'katakana' },
  { id: 'k8', kana: 'ク', romaji: 'ku', type: 'katakana' },
]

type GameMode = 'menu' | 'game' | 'results'
type KanaType = 'all' | 'hiragana' | 'katakana'
type GameType = 'multiple' | 'typing'

interface GameState {
  mode: GameMode
  currentIndex: number
  score: number
  streak: number
  lives: number
  kanaType: KanaType
  gameType: GameType
  currentCharacters: KanaCharacter[]
}

export default function KanaGame() {
  const [gameState, setGameState] = useState<GameState>({
    mode: 'menu',
    currentIndex: 0,
    score: 0,
    streak: 0,
    lives: 3,
    kanaType: 'all',
    gameType: 'multiple',
    currentCharacters: [],
  })

  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [typedAnswer, setTypedAnswer] = useState('')

  const startGame = (kanaType: KanaType, gameType: GameType) => {
    const hiragana = kanaType === 'all' || kanaType === 'hiragana' ? HIRAGANA_DATA : []
    const katakana = kanaType === 'all' || kanaType === 'katakana' ? KATAKANA_DATA : []
    const characters = [...hiragana, ...katakana].sort(() => Math.random() - 0.5)

    setGameState({
      mode: 'game',
      currentIndex: 0,
      score: 0,
      streak: 0,
      lives: 3,
      kanaType,
      gameType,
      currentCharacters: characters,
    })
    setSelectedAnswer(null)
    setTypedAnswer('')
  }

  const getCurrentQuestion = () => {
    return gameState.currentCharacters[gameState.currentIndex]
  }

  const getAnswerOptions = () => {
    const current = getCurrentQuestion()
    if (!current) return []

    const correct = current.romaji
    const allRomaji = gameState.currentCharacters
      .filter(c => c.type === current.type)
      .map(c => c.romaji)
      .filter((r, i, arr) => arr.indexOf(r) === i)

    const options = [correct]
    const others = allRomaji.filter(r => r !== correct)
    
    while (options.length < 4 && others.length > 0) {
      const randomIndex = Math.floor(Math.random() * others.length)
      options.push(others[randomIndex])
      others.splice(randomIndex, 1)
    }

    return options.sort(() => Math.random() - 0.5)
  }

  const handleAnswer = (answer: string) => {
    const current = getCurrentQuestion()
    const isCorrect = answer === current.romaji

    if (isCorrect) {
      setGameState(prev => ({
        ...prev,
        score: prev.score + 10,
        streak: prev.streak + 1,
      }))
    } else {
      setGameState(prev => ({
        ...prev,
        lives: prev.lives - 1,
        streak: 0,
      }))
    }

    setTimeout(() => {
      if (gameState.lives <= 1 && !isCorrect) {
        setGameState(prev => ({ ...prev, mode: 'results' }))
      } else if (gameState.currentIndex >= gameState.currentCharacters.length - 1) {
        setGameState(prev => ({ ...prev, mode: 'results' }))
      } else {
        setGameState(prev => ({
          ...prev,
          currentIndex: prev.currentIndex + 1,
        }))
        setSelectedAnswer(null)
        setTypedAnswer('')
      }
    }, 500)
  }

  const handleTypingSubmit = () => {
    if (typedAnswer.trim()) {
      handleAnswer(typedAnswer.toLowerCase())
    }
  }

  const playAudio = () => {
    const current = getCurrentQuestion()
    if (!current) return
    const utterance = new SpeechSynthesisUtterance(current.romaji)
    utterance.lang = 'ja-JP'
    window.speechSynthesis.speak(utterance)
  }

  if (gameState.mode === 'menu') {
    return <MenuScreen onStartGame={startGame} />
  }

  if (gameState.mode === 'results') {
    return (
      <ResultsScreen
        score={gameState.score}
        totalQuestions={gameState.currentCharacters.length}
        onBackToMenu={() => setGameState(prev => ({ ...prev, mode: 'menu' }))}
      />
    )
  }

  const current = getCurrentQuestion()
  const options = getAnswerOptions()

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 md:p-8">
      {/* Header */}
      <div className="w-full max-w-2xl mb-12">
        <button
          onClick={() => setGameState(prev => ({ ...prev, mode: 'menu' }))}
          className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors text-sm font-medium mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        {/* Stats */}
        <div className="flex justify-between items-center mb-12">
          <div className="flex gap-8">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">Score</p>
              <p className="text-2xl font-semibold text-foreground">{gameState.score}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">Streak</p>
              <p className="text-2xl font-semibold text-accent">{gameState.streak}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">Lives</p>
              <p className="text-2xl font-semibold text-secondary">{gameState.lives}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground mb-1">Progress</p>
            <p className="text-2xl font-semibold text-foreground">
              {gameState.currentIndex + 1}/{gameState.currentCharacters.length}
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="h-1 bg-border rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-300"
            style={{
              width: `${((gameState.currentIndex + 1) / gameState.currentCharacters.length) * 100}%`,
            }}
          />
        </div>
      </div>

      {/* Main content */}
      <div className="w-full max-w-2xl">
        <Card className="bg-card border-border shadow-sm p-0 overflow-hidden">
          <div className="p-8 md:p-12">
            {/* Question */}
            <div className="text-center mb-12">
              <p className="text-sm text-muted-foreground mb-4 uppercase tracking-widest">
                Match the character
              </p>
              <div className="text-7xl font-light text-foreground mb-8 font-serif">
                {current?.kana}
              </div>
              <button
                onClick={playAudio}
                className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
              >
                <Volume2 className="w-5 h-5" />
                <span className="text-sm font-medium">Hear pronunciation</span>
              </button>
            </div>

            {/* Answers */}
            {gameState.gameType === 'multiple' ? (
              <div className="grid grid-cols-2 gap-3 md:gap-4">
                {options.map((option) => (
                  <button
                    key={option}
                    onClick={() => {
                      setSelectedAnswer(option)
                      handleAnswer(option)
                    }}
                    className={`p-4 md:p-6 rounded-lg border-2 transition-all font-medium text-sm md:text-base ${
                      selectedAnswer === option
                        ? current?.romaji === option
                          ? 'border-green-500 bg-green-50 text-green-900 dark:bg-green-950 dark:text-green-100'
                          : 'border-destructive bg-red-50 text-destructive dark:bg-red-950 dark:text-red-100'
                        : 'border-border bg-background hover:border-primary hover:bg-accent/5 text-foreground'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                <input
                  type="text"
                  value={typedAnswer}
                  onChange={(e) => setTypedAnswer(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleTypingSubmit()}
                  placeholder="Type the romaji..."
                  className="w-full px-4 py-3 border-2 border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors"
                  autoFocus
                />
                <Button
                  onClick={handleTypingSubmit}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Submit
                </Button>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  )
}

function MenuScreen({ onStartGame }: { onStartGame: (type: KanaType, gameType: GameType) => void }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full text-center">
        {/* Title */}
        <div className="mb-8">
          <h1 className="text-5xl md:text-6xl font-light text-foreground mb-4">
            Kana Master
          </h1>
          <p className="text-lg text-muted-foreground font-light">
            Learn Japanese characters with grace and simplicity
          </p>
        </div>

        <div className="space-y-8 mt-16">
          {/* Kana Type Selection */}
          <div>
            <p className="text-sm uppercase tracking-widest text-muted-foreground mb-4">
              Choose script
            </p>
            <div className="grid grid-cols-3 gap-3 md:gap-4">
              {(['all', 'hiragana', 'katakana'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => onStartGame(type, 'multiple')}
                  className="group p-6 md:p-8 rounded-lg border-2 border-border hover:border-primary bg-card hover:bg-accent/5 transition-all"
                >
                  <div className="text-center">
                    {type === 'all' && <p className="text-3xl mb-2">全</p>}
                    {type === 'hiragana' && <p className="text-3xl mb-2">あ</p>}
                    {type === 'katakana' && <p className="text-3xl mb-2">ア</p>}
                    <p className="text-sm font-medium text-foreground capitalize">{type}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Game Mode Selection */}
          <div>
            <p className="text-sm uppercase tracking-widest text-muted-foreground mb-4">
              Game mode
            </p>
            <div className="grid grid-cols-2 gap-3 md:gap-4">
              {(['multiple', 'typing'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => onStartGame('all', mode)}
                  className="group p-6 md:p-8 rounded-lg border-2 border-border hover:border-primary bg-card hover:bg-accent/5 transition-all"
                >
                  <div className="text-center">
                    {mode === 'multiple' && (
                      <>
                        <p className="text-lg mb-2">◯ ✕</p>
                        <p className="text-sm font-medium text-foreground">Multiple Choice</p>
                      </>
                    )}
                    {mode === 'typing' && (
                      <>
                        <p className="text-lg mb-2">✎</p>
                        <p className="text-sm font-medium text-foreground">Typing</p>
                      </>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Quick start button */}
        <div className="mt-12">
          <Button
            onClick={() => onStartGame('all', 'multiple')}
            className="w-full md:w-auto bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg rounded-lg"
          >
            Start Learning
          </Button>
        </div>

        {/* Footer info */}
        <div className="mt-16 text-center">
          <p className="text-xs text-muted-foreground uppercase tracking-widest">
            Keyboard shortcuts: 1-4 to select • Enter to submit
          </p>
        </div>
      </div>
    </div>
  )
}

function ResultsScreen({
  score,
  totalQuestions,
  onBackToMenu,
}: {
  score: number
  totalQuestions: number
  onBackToMenu: () => void
}) {
  const percentage = Math.round((score / (totalQuestions * 10)) * 100)

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full text-center">
        <div className="mb-8">
          <h1 className="text-5xl md:text-6xl font-light text-foreground mb-4">
            Well done!
          </h1>
        </div>

        <Card className="bg-card border-border shadow-sm p-12 mb-8">
          <div className="space-y-6">
            <div>
              <p className="text-sm text-muted-foreground mb-2">Final Score</p>
              <p className="text-6xl font-light text-primary">{score}</p>
            </div>
            <div className="h-2 bg-border rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-accent"
                style={{ width: `${percentage}%` }}
              />
            </div>
            <div>
              <p className="text-2xl font-semibold text-foreground">{percentage}% correct</p>
              <p className="text-sm text-muted-foreground mt-2">
                {totalQuestions} characters practiced
              </p>
            </div>
          </div>
        </Card>

        <Button
          onClick={onBackToMenu}
          className="w-full md:w-auto bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg rounded-lg"
        >
          Back to Menu
        </Button>
      </div>
    </div>
  )
}
